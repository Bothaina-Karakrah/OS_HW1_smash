the tests file as you can see has the tests that we've used, each test has .in and .exp
.in files are the inputs that we used in the test on your smash
.exp files are the expected outpout
in addition to the tests there are test_src_1.txt and test_src_2.txt  which are used by some tests like copy
also you can find some binaries print_args_test and printSignals
those binaries are compiled on our linux (so use the only in the VM with our image) 
and used by some tests as external commands, they are simple programs one of them prints his arguments and the other prints the signals that it got